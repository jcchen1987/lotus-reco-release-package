#ifndef __OBJ_RECO_H__
#define __OBJ_RECO_H__

#include "lotus_common.h"


/*=====================================Usage=====================================
Offline Training:
    1. Create
    2. SetCamIntrinsic / SetGLPrjMatrix  (choose one)
    3. Train
    4. Destroy

Online Recognition:
    1. Create
    2. SetCamIntrinsic / SetGLPrjMatrix  (choose one)
    3. AddObj (call n times to add n objs)
    4. SetROI (optional)    
    5. ProcessVideo (for video or squential images)   /    Recognition (for one image)
    6. Destroy
=====================================Usage=====================================*/
class LOTUS_RECO_EXPORT CObjReco
{
public:
    enum EObjRecoType
    {
        EObjReco_FEATURE, ///< feature matching based obj recognition
        EObjReco_BB8,     ///< unsupported
        EObjReco_PoseNet  ///< unsupported
    };
    virtual ~CObjReco() {};

    //basic
    static string GetVersion();
    static CObjReco *Create(EObjRecoType eType = EObjReco_FEATURE);
    static void Destroy(CObjReco *pHandle);
    
    //training
    virtual int Train(const string &strDataBase, const TScanPackage &tScanPackage) = 0;
    
    //recognition    
    virtual int AddObj(const string &strDataBase) = 0;
    virtual int AddObj(const vector<string> &vstrDataBases) = 0;
    virtual int ClearObj() = 0;

    virtual int SetROI(const TImageU &tROI) = 0;

    virtual int ProcessVideo(const TImageU &tImg, const TCamIntrinsicParam &tCamIntrinsic, vector<TObjRecoResult> &vtResult) = 0;
    virtual int Recognition(const TImageU &tImg, const TCamIntrinsicParam &tCamIntrinsic, vector<TObjRecoResult> &vtResult) = 0;

    //advanced interface
    virtual int SetAdvancedParam(const string &strKey, void *pvValue) = 0;
    virtual int GetAdvancedParam(const string &strKey, void *pvValue) = 0;

};

#endif