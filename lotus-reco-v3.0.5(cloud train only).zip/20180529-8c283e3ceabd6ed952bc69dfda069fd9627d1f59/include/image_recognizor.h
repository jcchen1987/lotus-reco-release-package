#ifndef __IMAGE_RECOGNIZOR_H__
#define __IMAGE_RECOGNIZOR_H__
#include "lotus_common.h"

class LOTUS_RECO_EXPORT CImageRecognizor
{
public:
	static CImageRecognizor* Create(int iMethodType);
	static void Destroy(CImageRecognizor* pcHandle);
	virtual int Load(const string &strDatabase) = 0;
	virtual int Save(const string &strDatabase, const string strBowVoc = string("")) = 0;
	virtual int SetROI(const TROIRect &tROI) = 0;
	virtual int Train(const vector<TImageU>& vmImage, const vector<string> &vstrName = vector<string>(),
		const vector<TImageU> &vucMask = vector<TImageU>()) = 0;
	virtual int Recognition(const TImageU &tImg, string &strName, int feature_score = 0) = 0;
	virtual int QRCRecognition(const TImageU &tImg, string &strName, double* rvec, double* tvec) = 0;
	virtual int SetCamIntrinsic(const TCamIntrinsicParam &tParam) = 0;
	virtual int setFirstFrame(const TImageU &tImg, vector<float> vfBoundBox) = 0;
	virtual int Tracking(TImageU &tImg, vector<float> &vfBoundBox) = 0;
};
#endif